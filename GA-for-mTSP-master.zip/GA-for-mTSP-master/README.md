# Genetic Algorithm to solve Multiple Traveling Salesman Problem 
Here graph is covered using different agents having different routes. Routes only intersect at initial node.
Code is provided for both TSP and mTSP.

  * Nomenclature is diffrent with the terms 'dustbin' and 'route' being used for 'city' and 'tour' respectively.
  
