# Genetic Algorithm to solve mTSP
  - The results are good for large number of nodes
  - Values of numGenerations, numTrucks, mutationRate and populationSize can e tweaked to
    reach satisfactory results.
  - Refer to https://link.springer.com/chapter/10.1007/978-3-642-15220-7_12 for more information.
