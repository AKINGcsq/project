# Genetic Algorithm to solve Travelling Salesman Problem
Basic code for solving TSP
